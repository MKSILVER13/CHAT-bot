git clone
do cds
front end - npm i
backend - npm i
fonrtend - npm run dev
backend - node server.js

frontend - pip install -r requirements.txt
