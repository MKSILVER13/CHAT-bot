doc_keys = []
bad_docs = set()
counter_ =0
LANGFUSE_HOST="https://cloud.langfuse.com"
THRESHOLD=25
MONGO_URL ="mongodb+srv://hello:hello@atlascluster.t9cnxbb.mongodb.net/legal_chatbot?retryWrites=true&w=majority&appName=AtlasCluster"