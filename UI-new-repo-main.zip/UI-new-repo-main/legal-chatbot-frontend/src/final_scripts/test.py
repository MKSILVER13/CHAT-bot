from main import llm_answerer

question = "what are consultant obligations in adamgoldf agreement?"

e = llm_answerer(question)
print("final answer: ",e)